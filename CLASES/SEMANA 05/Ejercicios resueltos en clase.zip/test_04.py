"""Manejo de errores"""
"""
    Crear un programa usando exepciones donde no se puede
    realizar la suma entre diferentes tipos de datos
"""

def operaciones(a, b):

    try:
        #resultado = a + b
        resultado = a/b
    except TypeError:
        print("No se puede sumar un 'string' con un dato entero")
    except ZeroDivisionError:
        print("No se puede dividir entre cero")
    else:
        print("Resultado: {}".format(resultado))


operaciones(40, "Arequipa")
operaciones(40, 0)
