"""Manejo de errores"""
"""
    Exepción personalizada
"""

def validar_edad(edad):
    if edad < 0:
        raise ValueError("La edad debe ser mayor a 0")
    print("Edad correcta")
    return True

"""
raise:Va a generar un exepción deliberadamnete cuando una regla no se cumple
"""

validar_edad(15)
validar_edad(-1)
