"""Manejo de errores"""
"""
Crear nueva expeción en un except
"""

def dividir(a, b):
    try:
        result = a / b
    except ZeroDivisionError:
        print("No se puedo dividir entre 0")
        raise ValueError(f"No es posible la división entre {a} y {b}")

try:
    dividir(18, 0)
except ValueError as error:
    print("Error captura afuera: {}".format(error))
