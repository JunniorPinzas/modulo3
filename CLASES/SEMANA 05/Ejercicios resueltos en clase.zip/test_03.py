"""Manejo de errores"""
"""
TypeError
ZeroDivisionError
IndexError
KeyError
FileNotFoundError
ImportError
OverFlowError
"""
"""
Estructura y uso

try:
    Camino exitoso
    blode código 1
except 'excepción #1'
    bloque código 2
else:
    bloque código 3
"""

def division(a, b):
    try:
        resultado = a/b
        print("División correcta")
    except ZeroDivisionError:
        print("No es posible dividir estos valores, no es posible la división entre 0")
    else:
        print("Resultado: {}".format(resultado))

division(1000, 2)
division(400, 0)
division(2, 500)