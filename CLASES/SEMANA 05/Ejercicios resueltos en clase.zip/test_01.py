"""Manejo de errores"""
"""Error de sintaxis"""

while True
    print("Hola Pythonistas")