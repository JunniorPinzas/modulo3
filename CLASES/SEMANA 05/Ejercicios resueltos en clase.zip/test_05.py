"""Manejo de errores"""
"""
    IndexError: Evalúa un índice existente en una lista
"""

# Acceso a lista fuera de rango

def elemento_en(lista, i):
    try:
        return lista[i]
    except IndexError:
        return "Error de índice: {}, está fuera de rango de la lista su rango es de: 0 a {}".format(i, len(lista)-1)


nombres = ["Fernando", "Cathy", "Alberto"]
print(elemento_en(nombres, 2))
print(elemento_en(nombres, 6))