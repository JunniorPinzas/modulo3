"""Manejo de errores"""
"""Tipo de error: División"""

#var_1 = 500/0

#Tipo de error: Suma de tipos de datos diferentes
suma = 10000 + "¡Hola Pythonistas!"

